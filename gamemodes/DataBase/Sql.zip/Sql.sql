/*
[[[[[[[[[[[[[[[[[[[[SYSTEM BY ALEX GUITREEZ]]]]]]]]]]]]]]]]]]]]]]

• THIS SYSTEM WAS CREATED FOR SELL MY GAMEMODE WITHOUT PWN AMD PAWNO XD
• NO PWN AND PAWNO
• #First Scripter Make This System
• Dont Leake This Script We have AntiHack - AntiDeamx
• Leake = Deamx

[[[[[[[[[[[[[[[[[[[[SYSTEM BY ALEX GUITREEZ]]]]]]]]]]]]]]]]]]]]]]                                                                                                                                                                                                                                       */

#if defined DEBUG
	#define MYSQL_HOSTNAME  "localhost"
	#define MYSQL_DATABASE  "fnfnxpby1s"
	#define MYSQL_USERNAME  "fnfnxpby1s"
	#define MYSQL_PASSWORD  "fnfnxpby1s"
#else
	#define MYSQL_HOSTNAME  "localhost"
	#define MYSQL_DATABASE  "fnfnxpby1s"
	#define MYSQL_USERNAME  "fnfnxpby1s"
	#define MYSQL_PASSWORD  "fnfnxpby1s"
#endif