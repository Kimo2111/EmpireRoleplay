#pragma once

#include <amx/amx.h>
#include <amx/amx2.h>
#include <plugincommon.h>

typedef void(*logprintf_t)(const char* format, ...);
